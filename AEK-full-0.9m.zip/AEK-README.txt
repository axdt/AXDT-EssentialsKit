%VERSION% means AEK current version.

AET-Demo-%VERSION%-RUN.bat  RUN Demo
AET-Demo-%VERSION%.jar Demo 
AET-Demo-%VERSION% (folder) Demo Code
AXDT_EssentialKit-%VERSION%.jar Library
AXDT-EssentialsKit-%VERSION% (folder) Library Code
AXDT_EssentialKit-jd-%VERSION% (folder) Library JavaDoc