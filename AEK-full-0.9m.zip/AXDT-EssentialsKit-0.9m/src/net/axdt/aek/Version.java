package net.axdt.aek;

public class Version {

     private static final String TEAM = "AXDT";
     private static final String PROJECT = "AXDT Essentials Kit";
     private static final String VERSION = "0.9m";

     public static String getTeam(){
    	 return TEAM;
     }

     public static String getProject(){
    	 return PROJECT;
     }

     public static String getVersion(){
    	 return VERSION;
     }

}
