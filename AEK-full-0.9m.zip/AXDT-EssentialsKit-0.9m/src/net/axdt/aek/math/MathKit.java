package net.axdt.aek.math;

public class MathKit {
	public static int random(int min, int max){
		return (int)(Math.random()*max)+min;
	}

}
