package net.axdt.aek.exception;

public class AXInvaildArgumentException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AXInvaildArgumentException() {
	}

	public AXInvaildArgumentException(String arg0) {
		super(arg0);
	}

	public AXInvaildArgumentException(Throwable arg0) {
		super(arg0);
	}

	public AXInvaildArgumentException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

}
